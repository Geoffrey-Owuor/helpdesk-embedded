module.exports=[987760,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_collaborators_%5Buuid%5D_route_actions_0dvvf13.js.map