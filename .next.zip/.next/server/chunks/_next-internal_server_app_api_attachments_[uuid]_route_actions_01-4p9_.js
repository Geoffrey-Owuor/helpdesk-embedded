module.exports=[481748,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_attachments_%5Buuid%5D_route_actions_01-4p9_.js.map