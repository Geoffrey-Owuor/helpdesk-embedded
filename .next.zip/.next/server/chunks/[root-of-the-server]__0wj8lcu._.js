module.exports=[791230,e=>{e.v("/helpdesk/_next/static/media/issue_desk_light.3766eyti-8hen.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},41535,e=>{e.v("/helpdesk/_next/static/media/hotpoint_black_logo.1xyi48mlblloe.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},254799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},723862,e=>e.a(async(t,r)=>{try{let t=await e.y("pg-587764f78a6c7a9c");e.n(t),r()}catch(e){r(e)}},!0),918622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},556704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},832319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},324725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},270406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},193695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},861464,e=>e.a(async(t,r)=>{try{let i;var a=e.i(723862),s=t([a]);[a]=s.then?(await s)():s;let o={host:process.env.DATABASE_HOST,user:process.env.DATABASE_USER,password:process.env.DATABASE_PASSWORD,database:process.env.DATABASE_NAME,port:parseInt(process.env.DATABASE_PORT||"5432"),max:100,idleTimeoutMillis:3e4,connectionTimeoutMillis:15e3};async function n(e,t){let r=await i.connect();try{return(await r.query(e,t)).rows}finally{r.release()}}i=new a.Pool(o),e.s(["pool",0,i,"query",0,n]),r()}catch(e){r(e)}},!1),836494,e=>{"use strict";var t=e.i(871917),r=e.i(758823);e.s(["ReminderTemplate",0,function(e,a){let s=a.map(e=>{let a,s;return a=Math.floor((Date.now()-new Date(e.issue_created_at).getTime())/864e5),s=`https://hotpoint-apps.ngrok.app/helpdesk/dashboard/${e.issue_uuid}?type=issue&title=${encodeURIComponent(e.issue_title)}&description=${encodeURIComponent(e.issue_description)}`,`
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
      background-color: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      margin-bottom: 20px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    ">
      <tr>
        <td style="padding: 24px;">
          
          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 16px;">
            <tr>
              <td align="left" valign="middle">
                <span style="font-family: 'Courier New', monospace; font-size: 13px; font-weight: 600; color: #6b7280; background: #f3f4f6; padding: 4px 8px; border-radius: 6px;">
                  ${e.issue_reference_id}
                </span>
              </td>
              <td align="right" valign="middle">
                <table cellpadding="0" cellspacing="0" border="0">
                  <tr>
                    <td style="padding-right: 8px;">
                      ${(0,r.renderPriorityBadge)(e.issue_priority)}
                    </td>
                    <td>
                      ${(0,r.renderStatusBadge)(e.issue_status)}
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>

          <h3 style="margin: 0 0 8px 0; font-size: 17px; font-weight: 700; color: #111827; line-height: 1.4; overflow-wrap: break-word; white-space: pre-wrap;">
            ${e.issue_title}
          </h3>
          <p style="margin: 0 0 20px 0; font-size: 14px; color: #4b5563; line-height: 1.6; overflow-wrap: break-word; white-space: pre-wrap;">
            ${e.issue_description||"<em style='color: #9ca3af;'>No description provided</em>"}
          </p>

          <table cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 24px;">
            <tr>
              <td align="left" style="border-radius: 6px; background-color: #111827;">
                <a href="${s}" target="_blank" style="display: inline-block; padding: 10px 20px; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 13px; font-weight: 600; color: #ffffff; text-decoration: none; border-radius: 6px; text-align: center;">
                  View Issue &rarr;
                </a>
              </td>
            </tr>
          </table>

          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
            background-color: #f9fafb;
            border: 1px solid #f3f4f6;
            border-radius: 8px;
            padding: 16px;
          ">
            <tr>
              <td width="50%" valign="top" style="padding-right: 10px;">
                <div style="margin-bottom: 10px;">
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Submitter</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${e.issue_submitter_name}</span>
                </div>
                <div style="margin-bottom: 10px;">
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Assigned Agent</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${e.issue_agent_name||"Unassigned"}</span>
                </div>
                <div>
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Category</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${e.issue_type}</span>
                </div>
              </td>
              
              <td width="50%" valign="top">
                <div style="margin-bottom: 10px;">
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Created At</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${(0,t.dateFormatter)(e.issue_created_at)}</span>
                </div>
                <div style="margin-bottom: 10px;">
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Last Updated</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${(0,t.dateFormatter)(e.issue_updated_at)}</span>
                </div>
                <div>
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Issue Age</span>
                  <span style="font-size: 13px; font-weight: 700; color: #dc2626;">${a} Days Unresolved</span>
                </div>
              </td>
            </tr>
          </table>

        </td>
      </tr>
    </table>`}).join(""),n=a.filter(e=>"Critical"===e.issue_priority).length,i=a.filter(e=>"High"===e.issue_priority).length;return`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Unresolved Issues Reminder</title>
</head>
<body style="
  margin: 0; padding: 0;
  background-color: transparent;
  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
">

  <table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr>
      <td align="center">
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width: 680px;">

          <tr>
            <td style="
              background: #171717;
              padding: 20px;
              border-radius: 20px 20px 0 0;
            ">
              <table width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td align="left">
                    <span style="
                      font-size: 20px;
                      font-weight: 600;
                      color: #ffffff;
                      letter-spacing: -0.3px;
                    ">Help<span style="color: #a3a3a3;">Desk</span></span>
                  </td>
                  <td align="right">
                    <span style="font-size: 11px; font-weight: 600; color: #737373; letter-spacing: 0.5px; text-transform: uppercase;">
                      Reminder
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>


          <tr>
            <td style="
              background: #ffffff;
              padding: 24px 0px;
            ">

              <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
                background: #fef2f2;
                border: 1px solid #fecaca;
                border-left: 4px solid #dc2626;
                border-radius: 8px;
                margin-bottom: 32px;
              ">
                <tr>
                  <td style="padding: 16px 20px;">
                    <div style="font-size: 14px; font-weight: 700; color: #991b1b; margin-bottom: 6px;">
                      Issues Unresolved after 7 days
                    </div>
                    <p style="font-size: 13.5px; color: #b91c1c; margin: 0; line-height: 1.5;">
                      <strong>${e}</strong> has <strong>${a.length} unresolved issue${1!==a.length?"s":""}</strong>
                      that ${1!==a.length?"have":"has"} not been resolved after 7 days.
                      ${n>0?`<br><span style="margin-top: 6px; display: inline-block;">${n} Critical and ${i} High priority issue${n+i!==1?"s":""} need immediate action.</span>`:""}
                    </p>
                  </td>
                </tr>
              </table>

              <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 20px;">
                <tr>
                  <td style="
                    font-size: 12px; font-weight: 700;
                    text-transform: uppercase; letter-spacing: 1px;
                    color: #9ca3af; padding-bottom: 12px;
                    border-bottom: 2px solid #f3f4f6;
                  ">Unresolved Issues - ${e}</td>
                </tr>
              </table>

              ${s}

              <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top: 40px; border-top: 1px solid #f3f4f6; padding-top: 24px;">
                <tr>
                  <td align="center">
                    <p style="font-size: 12px; color: #9ca3af; margin: 0 0 4px;">This is an automated reminder from</p>
                    <p style="font-size: 13px; font-weight: 700; color: #404040; margin: 0 0 12px; letter-spacing: -0.2px;">HelpDesk</p>
                    <p style="font-size: 11.5px; color: #d1d5db; margin: 0;">Please do not reply to this email directly.</p>
                  </td>
                </tr>
              </table>

            </td>
          </tr>

          <tr>
            <td style="padding-top: 24px;" align="center">
              <p style="font-size: 11px; color: #9ca3af; margin: 0;">
                \xa9 ${new Date().getFullYear()} HelpDesk. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>`}])},780238,e=>e.a(async(t,r)=>{try{var a=e.i(861464),s=e.i(89171),n=e.i(344732),i=e.i(836494),o=t([a]);async function l(e){let t=e.nextUrl.searchParams,r=t.get("token"),o=t.get("email");if(!r||r!==process.env.CRON_SECRET)return s.NextResponse.json({error:"Unauthorized"},{status:401});if(!o)return s.NextResponse.json({error:"Email not provided"},{status:400});let l=`
      SELECT 
        issue_uuid, issue_reference_id, issue_submitter_name, issue_submitter_department,
        issue_target_department, issue_priority, issue_type, issue_title, issue_description, 
        issue_status, issue_agent_name, issue_agent_email, issue_created_at, issue_updated_at
      FROM issues_table
      WHERE issue_status != $1
        AND issue_status != $2
        AND issue_agent_email = $3
        AND issue_created_at <= NOW() - INTERVAL '7 days'
    `;try{let e=await (0,a.query)(l,["resolved","closed",o]);if(0===e.length)return s.NextResponse.json({success:!0,message:`No unresolved issues found for agent: ${o}`},{status:200});let t=(0,i.ReminderTemplate)(e[0].issue_agent_name,e);await (0,n.sendEmail)({to:o,subject:`[HelpDesk] ${e.length} Unresolved Issue${1!==e.length?"s":""} - Action Required`,html:t});let r={recipient:o,type:"Single agent reminder",sent:!0,count:e.length};return s.NextResponse.json({success:!0,summary:r},{status:200})}catch(e){return console.error("[reminder-cron] Fatal error:",e),s.NextResponse.json({success:!1,error:e instanceof Error?e.message:String(e)},{status:500})}}[a]=o.then?(await o)():o,e.s(["GET",0,l]),r()}catch(e){r(e)}},!1),19555,e=>e.a(async(t,r)=>{try{var a=e.i(747909),s=e.i(174017),n=e.i(996250),i=e.i(759756),o=e.i(561916),l=e.i(174677),p=e.i(869741),d=e.i(316795),c=e.i(487718),u=e.i(995169),g=e.i(47587),f=e.i(666012),x=e.i(570101),h=e.i(626937),m=e.i(10372),b=e.i(193695);e.i(820232);var y=e.i(600220),v=e.i(780238),w=t([v]);[v]=w.then?(await w)():w;let R=new a.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/triggers/targeted-reminder/route",pathname:"/api/triggers/targeted-reminder",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/triggers/targeted-reminder/route.ts",nextConfigOutput:"",userland:v,...{}}),{workAsyncStorage:E,workUnitAsyncStorage:A,serverHooks:k}=R;async function _(e,t,r){r.requestMeta&&(0,i.setRequestMeta)(e,r.requestMeta),R.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/triggers/targeted-reminder/route";a=a.replace(/\/index$/,"")||"/";let n=await R.prepare(e,t,{srcPage:a,multiZoneDraftMode:!1});if(!n)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:v,deploymentId:w,params:_,nextConfig:E,parsedUrl:A,isDraftMode:k,prerenderManifest:T,routerServerContext:C,isOnDemandRevalidate:N,revalidateOnlyGenerated:S,resolvedPathname:$,clientReferenceManifest:D,serverActionsManifest:P}=n,U=(0,p.normalizeAppPath)(a),I=!!(T.dynamicRoutes[U]||T.routes[$]),q=async()=>((null==C?void 0:C.render404)?await C.render404(e,t,A,!1):t.end("This page could not be found"),null);if(I&&!k){let e=!!T.routes[$],t=T.dynamicRoutes[U];if(t&&!1===t.fallback&&!e){if(E.adapterPath)return await q();throw new b.NoFallbackError}}let H=null;!I||R.isDev||k||(H=$,H="/index"===H?"/":H);let O=!0===R.isDev||!I,z=I&&!O;P&&D&&(0,l.setManifestsSingleton)({page:a,clientReferenceManifest:D,serverActionsManifest:P});let j=e.method||"GET",M=(0,o.getTracer)(),F=M.getActiveScopeSpan(),B=!!(null==C?void 0:C.isWrappedByNextServer),L=!!(0,i.getRequestMeta)(e,"minimalMode"),K=(0,i.getRequestMeta)(e,"incrementalCache")||await R.getIncrementalCache(e,E,T,L);null==K||K.resetRequestCache(),globalThis.__incrementalCache=K;let X={params:_,previewProps:T.preview,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:O,incrementalCache:K,cacheLifeProfiles:E.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,s)=>R.onRequestError(e,t,a,s,C)},sharedContext:{buildId:v,deploymentId:w}},W=new d.NodeNextRequest(e),V=new d.NodeNextResponse(t),G=c.NextRequestAdapter.fromNodeNextRequest(W,(0,c.signalFromNodeResponse)(t));try{let n,i=async e=>R.handle(G,X).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=M.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=r.get("next.route");if(s){let t=`${j} ${s}`;e.setAttributes({"next.route":s,"http.route":s,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",s),n.updateName(t))}else e.updateName(`${j} ${a}`)}),l=async n=>{var o,l;let p=async({previousCacheEntry:s})=>{try{if(!L&&N&&S&&!s)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await i(n);e.fetchMetrics=X.renderOpts.fetchMetrics;let o=X.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let l=X.renderOpts.collectedTags;if(!I)return await (0,f.sendResponse)(W,V,a,X.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,x.toNodeOutgoingHttpHeaders)(a.headers);l&&(t[m.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==X.renderOpts.collectedRevalidate&&!(X.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&X.renderOpts.collectedRevalidate,s=void 0===X.renderOpts.collectedExpire||X.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:X.renderOpts.collectedExpire;return{value:{kind:y.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:s}}}}catch(t){throw(null==s?void 0:s.isStale)&&await R.onRequestError(e,t,{routerKind:"App Router",routePath:a,routeType:"route",revalidateReason:(0,g.getRevalidateReason)({isStaticGeneration:z,isOnDemandRevalidate:N})},!1,C),t}},d=await R.handleResponse({req:e,nextConfig:E,cacheKey:H,routeKind:s.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:T,isRoutePPREnabled:!1,isOnDemandRevalidate:N,revalidateOnlyGenerated:S,responseGenerator:p,waitUntil:r.waitUntil,isMinimalMode:L});if(!I)return null;if((null==d||null==(o=d.value)?void 0:o.kind)!==y.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(l=d.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});L||t.setHeader("x-nextjs-cache",N?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),k&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,x.fromNodeOutgoingHttpHeaders)(d.value.headers);return L&&I||c.delete(m.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,h.getCacheControlHeader)(d.cacheControl)),await (0,f.sendResponse)(W,V,new Response(d.value.body,{headers:c,status:d.value.status||200})),null};B&&F?await l(F):(n=M.getActiveScopeSpan(),await M.withPropagatedContext(e.headers,()=>M.trace(u.BaseServerSpan.handleRequest,{spanName:`${j} ${a}`,kind:o.SpanKind.SERVER,attributes:{"http.method":j,"http.target":e.url}},l),void 0,!B))}catch(t){if(t instanceof b.NoFallbackError||await R.onRequestError(e,t,{routerKind:"App Router",routePath:U,routeType:"route",revalidateReason:(0,g.getRevalidateReason)({isStaticGeneration:z,isOnDemandRevalidate:N})},!1,C),I)throw t;return await (0,f.sendResponse)(W,V,new Response(null,{status:500})),null}}e.s(["handler",0,_,"patchFetch",0,function(){return(0,n.patchFetch)({workAsyncStorage:E,workUnitAsyncStorage:A})},"routeModule",0,R,"serverHooks",0,k,"workAsyncStorage",0,E,"workUnitAsyncStorage",0,A]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__0wj8lcu._.js.map