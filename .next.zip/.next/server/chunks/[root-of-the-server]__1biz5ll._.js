module.exports=[791230,e=>{e.v("/helpdesk/_next/static/media/issue_desk_light.3766eyti-8hen.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},41535,e=>{e.v("/helpdesk/_next/static/media/hotpoint_black_logo.1xyi48mlblloe.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},254799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},723862,e=>e.a(async(t,r)=>{try{let t=await e.y("pg-587764f78a6c7a9c");e.n(t),r()}catch(e){r(e)}},!0),918622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},556704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},832319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},324725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},270406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},193695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},861464,e=>e.a(async(t,r)=>{try{let i;var a=e.i(723862),n=t([a]);[a]=n.then?(await n)():n;let s={host:process.env.DATABASE_HOST,user:process.env.DATABASE_USER,password:process.env.DATABASE_PASSWORD,database:process.env.DATABASE_NAME,port:parseInt(process.env.DATABASE_PORT||"5432"),max:100,idleTimeoutMillis:3e4,connectionTimeoutMillis:15e3};async function o(e,t){let r=await i.connect();try{return(await r.query(e,t)).rows}finally{r.release()}}i=new a.Pool(s),e.s(["pool",0,i,"query",0,o]),r()}catch(e){r(e)}},!1),871917,e=>{"use strict";e.i(791230).default,e.i(41535).default;let t=new Date().getFullYear(),r={total:0,low:0,medium:0,high:0,critical:0},a={inProgress:{...r},open:{...r},resolved:{...r},closed:{...r}},n={total:0,active:0,inactive:0},o={totals:{...n},agents:{...n},admins:{...n},normalUsers:{...n}};e.s(["AUTOMATION_TYPE_FILTERS",0,["RPA","Staff Purchase","Requisition Hub"],"DefaultIssuesMappingCounts",0,{low:0,medium:0,high:0,critical:0},"DefaultUserCounts",0,o,"abbreviateUserName",0,e=>{if(e)return e.replace(/[^A-Z]/g,"")},"basePath",0,"/helpdesk","currentYear",0,t,"dateFormatter",0,e=>e?new Date(e).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}):"N/A","defaultCounts",0,a,"issuePrefixMapping",0,{"IT & Projects":"IT",Finance:"FIN",Marketing:"MKT",Operations:"OPS",Commercial:"COM","HR & Admin":"HR","Modern Trade":"MT",Retail:"RTL",B2B:"B2B","Internal Audit":"IA","Engineering & HVAC":"ENG",Security:"SEC","Service Center":"SVC",Directorate:"DIR"}],871917)},500874,(e,t,r)=>{t.exports=e.x("buffer",()=>require("buffer"))},223469,(e,t,r)=>{var a=e.r(500874),n=a.Buffer;function o(e,t){for(var r in e)t[r]=e[r]}function i(e,t,r){return n(e,t,r)}n.from&&n.alloc&&n.allocUnsafe&&n.allocUnsafeSlow?t.exports=a:(o(a,r),r.Buffer=i),i.prototype=Object.create(n.prototype),o(n,i),i.from=function(e,t,r){if("number"==typeof e)throw TypeError("Argument must not be a number");return n(e,t,r)},i.alloc=function(e,t,r){if("number"!=typeof e)throw TypeError("Argument must be a number");var a=n(e);return void 0!==t?"string"==typeof r?a.fill(t,r):a.fill(t):a.fill(0),a},i.allocUnsafe=function(e){if("number"!=typeof e)throw TypeError("Argument must be a number");return n(e)},i.allocUnsafeSlow=function(e){if("number"!=typeof e)throw TypeError("Argument must be a number");return a.SlowBuffer(e)}},499441,(e,t,r)=>{var a=Object.prototype.toString;t.exports=function(e){var t;return!0===e||!1===e||!!(t=e)&&"object"==typeof t&&"[object Boolean]"==a.call(e)}},715514,(e,t,r)=>{var a,n,o=Object.prototype,i=Function.prototype.toString,s=o.hasOwnProperty,l=i.call(Object),c=o.toString,u=(a=Object.getPrototypeOf,n=Object,function(e){return a(n(e))});t.exports=function(e){if(!(e&&"object"==typeof e)||"[object Object]"!=c.call(e)||function(e){var t=!1;if(null!=e&&"function"!=typeof e.toString)try{t=!!(e+"")}catch(e){}return t}(e))return!1;var t=u(e);if(null===t)return!0;var r=s.call(t,"constructor")&&t.constructor;return"function"==typeof r&&r instanceof r&&i.call(r)==l}},814747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},224361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},522734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},688947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},921517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},666680,(e,t,r)=>{t.exports=e.x("node:crypto",()=>require("node:crypto"))},344732,e=>{"use strict";e.i(789582);var t=e.i(926059);let r={auth:{clientId:process.env.AUTH_MICROSOFT_ENTRA_ID_ID,authority:`https://login.microsoftonline.com/${process.env.AUTH_MICROSOFT_ENTRA_ID_TENANT_ID}`,clientSecret:process.env.AUTH_MICROSOFT_ENTRA_ID_SECRET}},a=new t.ConfidentialClientApplication(r);async function n(){let e=await a.acquireTokenByClientCredential({scopes:["https://graph.microsoft.com/.default"]});return e?.accessToken}let o=async({to:e,cc:t,subject:r,html:a,attachments:o})=>{try{let i=await n();if(!i)throw Error("Failed to retrieve access token");let s=(Array.isArray(e)?e:[e]).map(e=>({emailAddress:{address:e}})),l=t?(Array.isArray(t)?t:[t]).map(e=>({emailAddress:{address:e}})):[],c=o?.map(e=>({"@odata.type":"#microsoft.graph.fileAttachment",name:e.filename,contentType:e.contentType,contentBytes:e.content})),u={message:{subject:r,body:{contentType:"HTML",content:a},toRecipients:s,ccRecipients:l,attachments:c||[]},saveToSentItems:"true"},d=0;for(;d<3;){d++;let e=await fetch(`https://graph.microsoft.com/v1.0/users/${process.env.EMAIL_SENDER}/sendMail`,{method:"POST",headers:{Authorization:`Bearer ${i}`,"Content-Type":"application/json"},body:JSON.stringify(u)});if(e.ok)return{success:!0};if(429===e.status){let t=e.headers.get("Retry-After"),r=t?1e3*parseInt(t,10):2e3*d;console.warn(`Graph API limit hit (429). Retrying in ${r/1e3}s... (Attempt ${d} of 3)`),await new Promise(e=>setTimeout(e,r));continue}let t=await e.json().catch(()=>({}));throw Error(t.error?.message||`Failed to send email via Graph (Status: ${e.status})`)}throw Error("Max retries reached. Failed to send email due to persistent throttling.")}catch(t){let e=t instanceof Error?t.message:"Unknown error";return console.error("Graph Email failed:",e),{success:!1,error:e}}};e.s(["sendEmail",0,o])},913279,e=>{"use strict";var t=e.i(871917),r=e.i(344732);let a=async e=>{let a=(e=>{let{title:r,category:a,dateReported:n,severity:o}=e,i=(0,t.dateFormatter)(n);return`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Bug Report: ${r}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: transparent;
            margin: 0;
            padding: 0;
        }
        .container {
            margin: 0 auto;
            max-width: 600px;
            background-color: #ffffff;
            border-radius: 12px;
            overflow: hidden;
        }
        .header {
            background-color: #c0392b;
            color: #ffffff;
            padding: 24px 32px;
        }
        .header h1 {
            margin: 0;
            font-size: 22px;
            font-weight: 700;
        }
        .header p {
            margin: 4px 0 0;
            font-size: 13px;
            opacity: 0.85;
        }
        .body {
            padding: 32px;
        }
        .field {
            margin-bottom: 20px;
        }
        .field label {
            display: block;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #888888;
            margin-bottom: 4px;
        }
        .field .value {
            font-size: 15px;
            color: #222222;
        }
        .divider {
            border: none;
            border-top: 1px solid #eeeeee;
            margin: 24px 0;
        }
        .footer {
            background-color: #f9f9f9;
            padding: 16px 32px;
            font-size: 12px;
            color: #aaaaaa;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🐛 Bug Report Submitted</h1>
            <p>A new bug has been reported and is awaiting review.</p>
        </div>
        <div class="body">
            <div class="field">
                <label>Title</label>
                <div class="value">${r}</div>
            </div>
            <hr class="divider" />
            <div class="field">
                <label>Category</label>
                <div class="value">${a}</div>
            </div>
            <div class="field">
                <label>Severity</label>
                <div class="value">${o}</div>
            </div>
            <div class="field">
                <label>Date Reported</label>
                <div class="value">${i}</div>
            </div>
        </div>
        <div class="footer">
            This is an automated notification. Please do not reply to this email.
        </div>
    </div>
</body>
</html>
    `})(e);await (0,r.sendEmail)({to:"geoffrey@hotpoint.co.ke",subject:"New Bug Report Submitted",html:a})};e.s(["SendBugReport",0,a],913279)},286341,e=>e.a(async(t,r)=>{try{var a=e.i(89171),n=e.i(861464),o=e.i(913279),i=t([n]);async function s(e){try{let{title:t,category:r,severity:i,steps:s,expected:l,actual:c,browserOs:u,extras:d}=await e.json(),p=`
         INSERT INTO bug_reports 
         (bug_title, bug_category, bug_severity, reproduction_steps, expected_behavior, actual_behavior, browser_os, additional_context)
         VALUES
         ($1, $2, $3, $4, $5, $6, $7, $8)
        `,f=[t,r,i,s,l,c,u,d];return await (0,n.query)(p,f),(0,o.SendBugReport)({title:t,dateReported:new Date().toLocaleDateString(),category:r,severity:i}),a.NextResponse.json({message:"Thank you for helping us improve the product!"},{status:200})}catch(e){return console.error("Error while trying to submit a bug report:",e),a.NextResponse.json({message:"Could not submit report, an error occured"},{status:500})}}[n]=i.then?(await i)():i,e.s(["POST",0,s]),r()}catch(e){r(e)}},!1),632224,e=>e.a(async(t,r)=>{try{var a=e.i(747909),n=e.i(174017),o=e.i(996250),i=e.i(759756),s=e.i(561916),l=e.i(174677),c=e.i(869741),u=e.i(316795),d=e.i(487718),p=e.i(995169),f=e.i(47587),h=e.i(666012),m=e.i(570101),g=e.i(626937),v=e.i(10372),y=e.i(193695);e.i(820232);var x=e.i(600220),b=e.i(286341),w=t([b]);[b]=w.then?(await w)():w;let A=new a.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/bug-report/route",pathname:"/api/bug-report",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/bug-report/route.ts",nextConfigOutput:"",userland:b,...{}}),{workAsyncStorage:T,workUnitAsyncStorage:E,serverHooks:S}=A;async function R(e,t,r){r.requestMeta&&(0,i.setRequestMeta)(e,r.requestMeta),A.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/bug-report/route";a=a.replace(/\/index$/,"")||"/";let o=await A.prepare(e,t,{srcPage:a,multiZoneDraftMode:!1});if(!o)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:b,deploymentId:w,params:R,nextConfig:T,parsedUrl:E,isDraftMode:S,prerenderManifest:_,routerServerContext:C,isOnDemandRevalidate:O,revalidateOnlyGenerated:N,resolvedPathname:I,clientReferenceManifest:P,serverActionsManifest:k}=o,q=(0,c.normalizeAppPath)(a),j=!!(_.dynamicRoutes[q]||_.routes[I]),D=async()=>((null==C?void 0:C.render404)?await C.render404(e,t,E,!1):t.end("This page could not be found"),null);if(j&&!S){let e=!!_.routes[I],t=_.dynamicRoutes[q];if(t&&!1===t.fallback&&!e){if(T.adapterPath)return await D();throw new y.NoFallbackError}}let U=null;!j||A.isDev||S||(U=I,U="/index"===U?"/":U);let M=!0===A.isDev||!j,$=j&&!M;k&&P&&(0,l.setManifestsSingleton)({page:a,clientReferenceManifest:P,serverActionsManifest:k});let B=e.method||"GET",F=(0,s.getTracer)(),H=F.getActiveScopeSpan(),L=!!(null==C?void 0:C.isWrappedByNextServer),K=!!(0,i.getRequestMeta)(e,"minimalMode"),z=(0,i.getRequestMeta)(e,"incrementalCache")||await A.getIncrementalCache(e,T,_,K);null==z||z.resetRequestCache(),globalThis.__incrementalCache=z;let G={params:R,previewProps:_.preview,renderOpts:{experimental:{authInterrupts:!!T.experimental.authInterrupts},cacheComponents:!!T.cacheComponents,supportsDynamicResponse:M,incrementalCache:z,cacheLifeProfiles:T.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>A.onRequestError(e,t,a,n,C)},sharedContext:{buildId:b,deploymentId:w}},X=new u.NodeNextRequest(e),V=new u.NodeNextResponse(t),W=d.NextRequestAdapter.fromNodeNextRequest(X,(0,d.signalFromNodeResponse)(t));try{let o,i=async e=>A.handle(W,G).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=F.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=r.get("next.route");if(n){let t=`${B} ${n}`;e.setAttributes({"next.route":n,"http.route":n,"next.span_name":t}),e.updateName(t),o&&o!==e&&(o.setAttribute("http.route",n),o.updateName(t))}else e.updateName(`${B} ${a}`)}),l=async o=>{var s,l;let c=async({previousCacheEntry:n})=>{try{if(!K&&O&&N&&!n)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await i(o);e.fetchMetrics=G.renderOpts.fetchMetrics;let s=G.renderOpts.pendingWaitUntil;s&&r.waitUntil&&(r.waitUntil(s),s=void 0);let l=G.renderOpts.collectedTags;if(!j)return await (0,h.sendResponse)(X,V,a,G.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,m.toNodeOutgoingHttpHeaders)(a.headers);l&&(t[v.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==G.renderOpts.collectedRevalidate&&!(G.renderOpts.collectedRevalidate>=v.INFINITE_CACHE)&&G.renderOpts.collectedRevalidate,n=void 0===G.renderOpts.collectedExpire||G.renderOpts.collectedExpire>=v.INFINITE_CACHE?void 0:G.renderOpts.collectedExpire;return{value:{kind:x.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:n}}}}catch(t){throw(null==n?void 0:n.isStale)&&await A.onRequestError(e,t,{routerKind:"App Router",routePath:a,routeType:"route",revalidateReason:(0,f.getRevalidateReason)({isStaticGeneration:$,isOnDemandRevalidate:O})},!1,C),t}},u=await A.handleResponse({req:e,nextConfig:T,cacheKey:U,routeKind:n.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:_,isRoutePPREnabled:!1,isOnDemandRevalidate:O,revalidateOnlyGenerated:N,responseGenerator:c,waitUntil:r.waitUntil,isMinimalMode:K});if(!j)return null;if((null==u||null==(s=u.value)?void 0:s.kind)!==x.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(l=u.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",O?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),S&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let d=(0,m.fromNodeOutgoingHttpHeaders)(u.value.headers);return K&&j||d.delete(v.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||d.get("Cache-Control")||d.set("Cache-Control",(0,g.getCacheControlHeader)(u.cacheControl)),await (0,h.sendResponse)(X,V,new Response(u.value.body,{headers:d,status:u.value.status||200})),null};L&&H?await l(H):(o=F.getActiveScopeSpan(),await F.withPropagatedContext(e.headers,()=>F.trace(p.BaseServerSpan.handleRequest,{spanName:`${B} ${a}`,kind:s.SpanKind.SERVER,attributes:{"http.method":B,"http.target":e.url}},l),void 0,!L))}catch(t){if(t instanceof y.NoFallbackError||await A.onRequestError(e,t,{routerKind:"App Router",routePath:q,routeType:"route",revalidateReason:(0,f.getRevalidateReason)({isStaticGeneration:$,isOnDemandRevalidate:O})},!1,C),j)throw t;return await (0,h.sendResponse)(X,V,new Response(null,{status:500})),null}}e.s(["handler",0,R,"patchFetch",0,function(){return(0,o.patchFetch)({workAsyncStorage:T,workUnitAsyncStorage:E})},"routeModule",0,A,"serverHooks",0,S,"workAsyncStorage",0,T,"workUnitAsyncStorage",0,E]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__1biz5ll._.js.map