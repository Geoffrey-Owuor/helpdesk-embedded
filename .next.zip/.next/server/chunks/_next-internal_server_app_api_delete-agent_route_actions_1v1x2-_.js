module.exports=[88184,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_delete-agent_route_actions_1v1x2-_.js.map