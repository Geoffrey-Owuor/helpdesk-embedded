module.exports=[871917,e=>{"use strict";e.i(791230).default,e.i(41535).default;let t=new Date().getFullYear(),r={total:0,low:0,medium:0,high:0,critical:0},o={inProgress:{...r},open:{...r},resolved:{...r},closed:{...r}},i={total:0,active:0,inactive:0},n={totals:{...i},agents:{...i},admins:{...i},normalUsers:{...i}};e.s(["AUTOMATION_TYPE_FILTERS",0,["RPA","Staff Purchase","Requisition Hub"],"DefaultIssuesMappingCounts",0,{low:0,medium:0,high:0,critical:0},"DefaultUserCounts",0,n,"abbreviateUserName",0,e=>{if(e)return e.replace(/[^A-Z]/g,"")},"basePath",0,"/helpdesk","currentYear",0,t,"dateFormatter",0,e=>e?new Date(e).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}):"N/A","defaultCounts",0,o,"issuePrefixMapping",0,{"IT & Projects":"IT",Finance:"FIN",Marketing:"MKT",Operations:"OPS",Commercial:"COM","HR & Admin":"HR","Modern Trade":"MT",Retail:"RTL",B2B:"B2B","Internal Audit":"IA","Engineering & HVAC":"ENG",Security:"SEC","Service Center":"SVC",Directorate:"DIR"}],871917)},500874,(e,t,r)=>{t.exports=e.x("buffer",()=>require("buffer"))},223469,(e,t,r)=>{var o=e.r(500874),i=o.Buffer;function n(e,t){for(var r in e)t[r]=e[r]}function a(e,t,r){return i(e,t,r)}i.from&&i.alloc&&i.allocUnsafe&&i.allocUnsafeSlow?t.exports=o:(n(o,r),r.Buffer=a),a.prototype=Object.create(i.prototype),n(i,a),a.from=function(e,t,r){if("number"==typeof e)throw TypeError("Argument must not be a number");return i(e,t,r)},a.alloc=function(e,t,r){if("number"!=typeof e)throw TypeError("Argument must be a number");var o=i(e);return void 0!==t?"string"==typeof r?o.fill(t,r):o.fill(t):o.fill(0),o},a.allocUnsafe=function(e){if("number"!=typeof e)throw TypeError("Argument must be a number");return i(e)},a.allocUnsafeSlow=function(e){if("number"!=typeof e)throw TypeError("Argument must be a number");return o.SlowBuffer(e)}},499441,(e,t,r)=>{var o=Object.prototype.toString;t.exports=function(e){var t;return!0===e||!1===e||!!(t=e)&&"object"==typeof t&&"[object Boolean]"==o.call(e)}},715514,(e,t,r)=>{var o,i,n=Object.prototype,a=Function.prototype.toString,l=n.hasOwnProperty,s=a.call(Object),p=n.toString,d=(o=Object.getPrototypeOf,i=Object,function(e){return o(i(e))});t.exports=function(e){if(!(e&&"object"==typeof e)||"[object Object]"!=p.call(e)||function(e){var t=!1;if(null!=e&&"function"!=typeof e.toString)try{t=!!(e+"")}catch(e){}return t}(e))return!1;var t=d(e);if(null===t)return!0;var r=l.call(t,"constructor")&&t.constructor;return"function"==typeof r&&r instanceof r&&a.call(r)==s}},814747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},224361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},522734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},688947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},921517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},666680,(e,t,r)=>{t.exports=e.x("node:crypto",()=>require("node:crypto"))},344732,e=>{"use strict";e.i(789582);var t=e.i(926059);let r={auth:{clientId:process.env.AUTH_MICROSOFT_ENTRA_ID_ID,authority:`https://login.microsoftonline.com/${process.env.AUTH_MICROSOFT_ENTRA_ID_TENANT_ID}`,clientSecret:process.env.AUTH_MICROSOFT_ENTRA_ID_SECRET}},o=new t.ConfidentialClientApplication(r);async function i(){let e=await o.acquireTokenByClientCredential({scopes:["https://graph.microsoft.com/.default"]});return e?.accessToken}let n=async({to:e,cc:t,subject:r,html:o,attachments:n})=>{try{let a=await i();if(!a)throw Error("Failed to retrieve access token");let l=(Array.isArray(e)?e:[e]).map(e=>({emailAddress:{address:e}})),s=t?(Array.isArray(t)?t:[t]).map(e=>({emailAddress:{address:e}})):[],p=n?.map(e=>({"@odata.type":"#microsoft.graph.fileAttachment",name:e.filename,contentType:e.contentType,contentBytes:e.content})),d={message:{subject:r,body:{contentType:"HTML",content:o},toRecipients:l,ccRecipients:s,attachments:p||[]},saveToSentItems:"true"},c=0;for(;c<3;){c++;let e=await fetch(`https://graph.microsoft.com/v1.0/users/${process.env.EMAIL_SENDER}/sendMail`,{method:"POST",headers:{Authorization:`Bearer ${a}`,"Content-Type":"application/json"},body:JSON.stringify(d)});if(e.ok)return{success:!0};if(429===e.status){let t=e.headers.get("Retry-After"),r=t?1e3*parseInt(t,10):2e3*c;console.warn(`Graph API limit hit (429). Retrying in ${r/1e3}s... (Attempt ${c} of 3)`),await new Promise(e=>setTimeout(e,r));continue}let t=await e.json().catch(()=>({}));throw Error(t.error?.message||`Failed to send email via Graph (Status: ${e.status})`)}throw Error("Max retries reached. Failed to send email due to persistent throttling.")}catch(t){let e=t instanceof Error?t.message:"Unknown error";return console.error("Graph Email failed:",e),{success:!1,error:e}}};e.s(["sendEmail",0,n])},758823,e=>{"use strict";var t=e.i(871917);let r={open:{bg:"#fef9ec",color:"#92680a",label:"Open"},"in progress":{bg:"#EEF2FF",color:"#4338CA",label:"In Progress"},resolved:{bg:"#f0fdf4",color:"#166534",label:"Resolved"},closed:{bg:"#eff6ff",color:"#1d4ed8",label:"Closed"}},o={Low:{bg:"#f8fafc",color:"#475569",border:"#cbd5e1"},Medium:{bg:"#fffbeb",color:"#92400e",border:"#fcd34d"},High:{bg:"#fff7ed",color:"#c2410c",border:"#fb923c"},Critical:{bg:"#fef2f2",color:"#991b1b",border:"#f87171"}};function i(e){let t=r[e];return`
        <span style="
        display: inline-flex;
        align-items: center;
        justify-content: center; /* Ensures content is centered horizontally if width is fixed */
        gap: 6px;
        background: ${t.bg};
        color: ${t.color};
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.3px;
        padding: 4px 12px; /* Balanced padding */
        border-radius: 20px;
        white-space: nowrap;
        line-height: 1; /* Prevents text descent from pushing the box height */
      ">
        ${t.label}
      </span>
    `}function n(e){let t=o[e];return`
    <span style="
      display: inline-block;
      background: ${t.bg};
      color: ${t.color};
      border: 1px solid ${t.border};
      font-size: 12px;
      font-weight: 600;
      padding: 3px 10px;
      border-radius: 4px;
      white-space: nowrap;
    ">${e}</span>`}function a(e,t){return`
    <tr>
      <td style="
        padding: 11px 16px;
        font-size: 12.5px;
        font-weight: 600;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        white-space: nowrap;
        width: 160px;
        vertical-align: top;
        border-bottom: 1px solid #f3f4f6;
      ">${e}</td>
      <td style="
        padding: 11px 16px;
        font-size: 13.5px;
        color: #111827;
        border-bottom: 1px solid #f3f4f6;
        vertical-align: top;
      ">${t}</td>
    </tr>`}function l(e,t){return`
    <!-- Message Section -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top: 24px;">
      <tr>
        <td>
          <!-- Section Header -->
          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 14px;">
            <tr>
              <td style="
                font-size: 11px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 1px;
                color: #9ca3af;
                padding-bottom: 10px;
                border-bottom: 1px solid #e5e7eb;
              ">${e}</td>
            </tr>
          </table>

          <!-- Message Card -->
          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
            background: #fffbeb;
            border: 1px solid #fcd34d;
            border-left: 3px solid #f59e0b;
            border-radius: 6px;
          ">
            <tr>
              <td style="padding: 14px 18px;">
                <p style="
                  font-size: 13.5px;
                  line-height: 1.65;
                  color: #374151;
                  margin: 0;
                  padding: 0;
                ">${t}</p>
              </td>
            </tr>
          </table>

        </td>
      </tr>
    </table>`}e.s(["generateIssueNotificationEmail",0,function(e,r){let o,{title:s,description:p,body:d,comment:c,remarks:f,reasonReopened:g,reasonEscalated:b}=e,u=`https://hotpoint-apps.ngrok.app/helpdesk/dashboard/${r}?type=issue&title=${encodeURIComponent(d.issueTitle)}&description=${encodeURIComponent(d.issueDescription)}`,m=i(d.status),x=n(d.priority),h=c?(o=(0,t.abbreviateUserName)(c.author),`
    <!-- Comment Section -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top: 24px;">
      <tr>
        <td>
          <!-- Section Header -->
          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 14px;">
            <tr>
              <td style="
                font-size: 11px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 1px;
                color: #9ca3af;
                padding-bottom: 10px;
                border-bottom: 1px solid #e5e7eb;
              ">New Comment</td>
            </tr>
          </table>

          <!-- Comment Card -->
          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-left: 3px solid #404040;
            border-radius: 6px;
          ">
            <tr>
              <td style="padding: 16px 18px;">
                <!-- Author row -->
                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 10px;">
                  <tr>
                    <td style="width: 34px; vertical-align: middle;">
                      <div style="
                        width: 32px; height: 32px;
                        background: #262626;
                        color: #ffffff;
                        border-radius: 50%;
                        font-size: 12px;
                        font-weight: 700;
                        text-align: center;
                        line-height: 32px;
                        font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
                      ">${o}</div>
                    </td>
                    <td style="padding-left: 10px; vertical-align: middle;">
                      <div style="font-size: 13.5px; font-weight: 600; color: #111827;">${c.author}</div>
                      <div style="font-size: 11.5px; color: #9ca3af; margin-top: 1px;">${c.submittedAt}</div>
                    </td>
                  </tr>
                </table>
                <!-- Comment body -->
                <p style="
                  font-size: 13.5px;
                  line-height: 1.65;
                  color: #374151;
                  margin: 0;
                  padding: 0;
                ">${c.content}</p>
              </td>
            </tr>
          </table>

        </td>
      </tr>
    </table>`):"",y=f?l("Remarks",f):"",w=g?l("Reason Reopened",g):"",v=b?l("Reason Escalated",b):"";return`
 <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>${s}</title>
    <!--[if mso]>
    <noscript>
      <xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml>
    </noscript>
    <![endif]-->
  </head>
  <body style="
    margin: 0;
    padding: 0;
    background-color: transparent;
    font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
  ">

    <!-- Outer wrapper -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td align="center">

          <!-- Email card (max 620px) -->
          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width: 620px;">

            <!-- ── HEADER ── -->
            <tr>
              <td style="
                background: #171717;
                padding: 20px;
                border-radius: 20px 20px 0 0;
              ">
                <table width="100%" cellpadding="0" cellspacing="0" border="0" role="presentation">
                  <tr>
                    <td align="left" style="padding-right: 10px;">
                      <span style="
                        font-size: 20px;
                        font-weight: 600;
                        color: #ffffff;
                        letter-spacing: -0.3px;
                      ">Help<span style="color: #a3a3a3;">Desk</span></span>
                    </td>
                    
                    <td align="right" style="padding-left: 10px;">
                      <span style="
                        font-size: 11px;
                        font-weight: 600;
                        color: #737373;
                        letter-spacing: 0.5px;
                        text-transform: uppercase;
                      ">Notification</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- ── BODY ── -->
            <tr>
              <td style="
                background: #ffffff;
                padding: 24px 0px;
              ">

                <!-- Title & Description -->
                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 24px;">
                  <tr>
                    <td>
                      <h1 style="
                        font-size: 20px;
                        font-weight: 700;
                        color: #111827;
                        margin: 0 0 10px 0;
                        letter-spacing: -0.3px;
                        line-height: 1.3;
                      ">${s}</h1>
                      <p style="
                        font-size: 14px;
                        line-height: 1.6;
                        color: #6b7280;
                        margin: 0;
                      ">${p}</p>
                    </td>
                  </tr>
                </table>

                <!-- Optional Issue Remarks Section -->
                ${y}

                <!-- Optional Comment Section -->
                ${h}

                <!-- Optional Reason Reopened Section -->
                ${w}

                <!-- Optional Reason Escalated Section -->
                ${v}

              
                <!-- View Issue Button -->
                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top: 24px; margin-bottom:24px;">
                  <tr>
                    <td align="center">
                      <a href="${u}" style="
                        display: inline-block;
                        background: #171717;
                        color: #ffffff;
                        font-size: 13.5px;
                        font-weight: 600;
                        text-decoration: none;
                        padding: 12px 28px;
                        border-radius: 6px;
                        letter-spacing: 0.2px;
                      ">View Issue →</a>
                    </td>
                  </tr>
                </table>

                <!-- Section label: Issue Details -->
                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 14px;">
                  <tr>
                    <td style="
                      font-size: 11px;
                      font-weight: 700;
                      text-transform: uppercase;
                      letter-spacing: 1px;
                      color: #9ca3af;
                    ">Issue Details</td>
                  </tr>
                </table>

                <!-- Metadata table -->
                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
                  border: 1px solid #e5e7eb;
                  border-radius: 8px;
                  overflow: hidden;
                  border-collapse: separate;
                  border-spacing: 0;
                ">
                  ${a("Reference No.",`<span style="font-family: 'Courier New', monospace; font-size: 13px; color: #374151;">${d.referenceNo}</span>`)}
                  ${a("Type",d.type)}
                  ${a("Agent",d.agent)}
                  ${a("Priority",x)}
                  ${a("Status",m)}
                  ${a("Submitter",d.submitter)}
                  ${a("Date Submitted",(0,t.dateFormatter)(d.date))}
                  ${a("Admin",d.admin)}
                  <tr>
                    <td colspan="2" style="
                      padding: 14px 16px 6px;
                      font-size: 12.5px;
                      font-weight: 600;
                      color: #6b7280;
                      text-transform: uppercase;
                      letter-spacing: 0.5px;
                    ">Issue Title</td>
                  </tr>
                  <tr>
                    <td colspan="2" style="
                      padding: 4px 16px 16px;
                      font-size: 14px;
                      font-weight: 600;
                      color: #111827;
                      border-bottom: 1px solid #f3f4f6;
                    ">${d.issueTitle}</td>
                  </tr>
                  <tr>
                    <td colspan="2" style="
                      padding: 14px 16px 6px;
                      font-size: 12.5px;
                      font-weight: 600;
                      color: #6b7280;
                      text-transform: uppercase;
                      letter-spacing: 0.5px;
                    ">Issue Description</td>
                  </tr>
                  <tr>
                    <td colspan="2" style="
                      padding: 4px 16px 16px;
                      font-size: 13.5px;
                      line-height: 1.65;
                      color: #374151;
                    ">${d.issueDescription}</td>
                  </tr>
                </table>

                <!-- ── FOOTER ── -->
                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top: 36px;">
                  <tr>
                    <td align="center">
                      <p style="
                        font-size: 12px;
                        color: #9ca3af;
                        margin: 0 0 4px;
                      ">This is an automated notification from</p>
                      <p style="
                        font-size: 13px;
                        font-weight: 700;
                        color: #404040;
                        margin: 0 0 12px;
                        letter-spacing: -0.2px;
                      ">HelpDesk</p>
                      <p style="
                        font-size: 11.5px;
                        color: #d1d5db;
                        margin: 0;
                      ">Please do not reply to this email directly.</p>
                    </td>
                  </tr>
                </table>

              </td>
            </tr>

            <!-- Bottom spacer -->
            <tr>
              <td style="padding-top: 20px; padding-bottom:14px;" align="center">
                <p style="font-size: 11px; color: #9ca3af; margin: 0;">
                  \xa9 ${new Date().getFullYear()} HelpDesk. All rights reserved.
                </p>
              </td>
            </tr>

          </table>
        </td>
      </tr>
    </table>

  </body>
  </html>
  `},"renderPriorityBadge",0,n,"renderStatusBadge",0,i])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gdk9mq._.js.map