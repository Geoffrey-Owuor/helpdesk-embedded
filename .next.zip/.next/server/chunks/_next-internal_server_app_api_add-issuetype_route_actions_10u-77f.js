module.exports=[130078,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_add-issuetype_route_actions_10u-77f.js.map