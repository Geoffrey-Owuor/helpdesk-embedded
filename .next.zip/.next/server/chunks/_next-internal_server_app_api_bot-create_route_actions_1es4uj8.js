module.exports=[920376,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bot-create_route_actions_1es4uj8.js.map