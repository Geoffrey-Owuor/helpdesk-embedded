module.exports=[536778,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_notifications_user-changelogs_route_actions_1wxf28o.js.map