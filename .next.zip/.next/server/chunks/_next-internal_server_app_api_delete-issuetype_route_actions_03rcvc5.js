module.exports=[882324,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_delete-issuetype_route_actions_03rcvc5.js.map