module.exports=[735852,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_escalate-issue_route_actions_1xxjz6n.js.map