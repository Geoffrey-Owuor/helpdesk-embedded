module.exports=[791230,e=>{e.v("/helpdesk/_next/static/media/issue_desk_light.3766eyti-8hen.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},41535,e=>{e.v("/helpdesk/_next/static/media/hotpoint_black_logo.1xyi48mlblloe.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},254799,(e,t,a)=>{t.exports=e.x("crypto",()=>require("crypto"))},723862,e=>e.a(async(t,a)=>{try{let t=await e.y("pg-587764f78a6c7a9c");e.n(t),a()}catch(e){a(e)}},!0),918622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},556704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},832319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},324725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},270406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},193695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},861464,e=>e.a(async(t,a)=>{try{let n;var r=e.i(723862),s=t([r]);[r]=s.then?(await s)():s;let o={host:process.env.DATABASE_HOST,user:process.env.DATABASE_USER,password:process.env.DATABASE_PASSWORD,database:process.env.DATABASE_NAME,port:parseInt(process.env.DATABASE_PORT||"5432"),max:100,idleTimeoutMillis:3e4,connectionTimeoutMillis:15e3};async function i(e,t){let a=await n.connect();try{return(await a.query(e,t)).rows}finally{a.release()}}n=new r.Pool(o),e.s(["pool",0,n,"query",0,i]),a()}catch(e){a(e)}},!1),817374,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0});var r={ActionDidNotRevalidate:function(){return i},ActionDidRevalidateDynamicOnly:function(){return o},ActionDidRevalidateStaticAndDynamic:function(){return n}};for(var s in r)Object.defineProperty(a,s,{enumerable:!0,get:r[s]});let i=0,n=1,o=2},698830,e=>e.a(async(t,a)=>{try{var r=e.i(861464),s=t([r]);[r]=s.then?(await s)():s;let n=null,o=!0,l=0;async function i(){return Date.now()-l<5e3?o:n||(n=(async()=>{try{await (0,r.query)("SELECT 1"),o=!0}catch(e){console.error("DB Health Probe Failed:",e),o=!1}finally{l=Date.now(),n=null}return o})())}e.s(["checkDbHealth",0,i]),a()}catch(e){a(e)}},!1),911921,e=>e.a(async(t,a)=>{try{var r=e.i(89171),s=e.i(510968),i=e.i(698830),n=t([i]);[i]=n.then?(await n)():n,e.s(["withAuth",0,e=>async(t,{params:a})=>{if(!await (0,i.checkDbHealth)())return r.NextResponse.json({message:"Service Temporarily Unavailable"},{status:503});let n=await (0,s.verifyAccessTokenJWT)();if(!n)return r.NextResponse.json({message:"User is not authenticated"},{status:401});let o=await a||{};return e({request:t,params:o,user:n})}]),a()}catch(e){a(e)}},!1),280874,e=>e.a(async(t,a)=>{try{var r=e.i(861464),s=t([r]);[r]=s.then?(await s)():s;let i=async e=>{let t=`
    SELECT issue_reference_id, issue_target_department, issue_type, 
    issue_agent_name, issue_priority, issue_status, issue_submitter_name,
    issue_assigner_name, issue_title, issue_description, issue_submitter_email, 
    issue_agent_email, issue_created_at, issue_remarks, issue_assigner_email
    FROM issues_table WHERE issue_uuid = $1
    `,a=(await (0,r.query)(t,[e]))[0],s=a.issue_remarks??void 0,i=(await (0,r.query)("SELECT emails FROM group_emails WHERE department = $1 LIMIT 1",[a.issue_target_department]))[0].emails??void 0,n=await (0,r.query)("SELECT collaborator_email FROM issue_collaborators WHERE issue_id = $1",[e]),o={referenceNo:a.issue_reference_id,type:a.issue_type,agent:a.issue_agent_name,priority:a.issue_priority,date:a.issue_created_at,status:a.issue_status,submitter:a.issue_submitter_name,admin:a.issue_assigner_name,issueTitle:a.issue_title,issueDescription:a.issue_description},l=[...new Set([a.issue_submitter_email,a.issue_agent_email,a.issue_assigner_email,...n.map(e=>e.collaborator_email)])].filter(Boolean);return{issueData:o,emails:l,ccEmails:i,remarks:s}};e.s(["getEmailData",0,i]),a()}catch(e){a(e)}},!1),372291,e=>e.a(async(t,a)=>{try{var r=e.i(344732),s=e.i(758823),i=e.i(280874),n=e.i(871917),o=t([i]);[i]=o.then?(await o)():o;let l=async({title:e,uuid:t,description:a,comment:o="",reasonReopened:l="",reasonEscalated:c="",author:p="",attachments:d,prevAgentEmail:u})=>{let m=o?{author:p,content:o,submittedAt:(0,n.dateFormatter)(new Date().toLocaleDateString())}:void 0,{issueData:y,emails:h,ccEmails:g,remarks:x}=await (0,i.getEmailData)(t),_=u?h.includes(u)?h:[...h,u]:h,b=(0,s.generateIssueNotificationEmail)({title:e,description:a,body:y,remarks:x,reasonReopened:l,reasonEscalated:c,comment:m},t);await (0,r.sendEmail)({to:_,cc:g,subject:e,html:b,attachments:d})};e.s(["emailSender",0,l]),a()}catch(e){a(e)}},!1),924868,(e,t,a)=>{t.exports=e.x("fs/promises",()=>require("fs/promises"))},661722,e=>{"use strict";var t=e.i(871917);e.s(["default",0,(e,a)=>`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to HelpDesk - Setup Your Account</title>
    <style>
        /* Resets to ensure consistent rendering across clients */
        body { margin: 0; padding: 0; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: transparent; color: #51545E; }
        table { border-spacing: 0; width: 100%; }
        td { padding: 0; }
        img { border: 0; }
        .wrapper { width: 100%; table-layout: fixed; padding-bottom: 40px; }
        .main { margin: 0 auto; width: 100%; max-width: 600px; border-spacing: 0; font-family: sans-serif; color: #4a4a4a; border-radius: 12px; }
        .header { padding: 40px 0; text-align: center; }
        .content { padding: 0 40px 40px; }
        .footer { text-align: center; font-size: 12px; color: #999999; padding-top: 20px; }
        
        /* Typography */
        h1 { font-size: 24px; font-weight: bold; margin: 0 0 20px; color: #333333; }
        p { font-size: 16px; line-height: 1.6; margin: 0 0 20px; }
        
        /* Password Highlight Box */
        .password-box { background-color: #f8f9fa; border: 1px dashed #2c3e50; border-radius: 6px; padding: 15px; text-align: center; margin: 20px 0; font-family: monospace; font-size: 18px; font-weight: bold; color: #2c3e50; letter-spacing: 2px;}

        /* Button Style */
        .btn-container { text-align: center; margin: 30px 0; }
        .btn-container a { color: #ffffff; text-decoration: none; }
        .btn { display: inline-block; background-color: #2c3e50; font-size: 16px; font-weight: bold; padding: 14px 30px; border-radius: 6px; }
        
        /* Link Fallback */
        .link-fallback { font-size: 12px; color: #999999; word-break: break-all; margin-top: 20px; }
        .link-fallback a { color: #2c3e50; }
    </style>
</head>
<body>
    <center class="wrapper">
        <table class="main" width="100%">
            <tr>
                <td class="header">
                   <h2 style="color: #2c3e50; margin:0;">HelpDesk</h2>
                </td>
            </tr>

            <tr>
                <td class="content">
                    <h1>Welcome to HelpDesk!</h1>
                    <p>Hello,</p>
                    <p>An account has been created for you on HelpDesk. To get started, you will need to log in and set up your own new password.</p>
                    
                    <p>Your temporary login password is:</p>
                    
                    <div class="password-box">
                        ${a}
                    </div>

                    <p>Click the button below to complete your account setup and choose your new password.</p>
                    
                    <div class="btn-container">
                        <a href="${e}" class="btn">Setup My Account</a>
                    </div>

                    <p>If the button doesn't work, you can copy and paste the following link into your browser:</p>
                    <p class="link-fallback"><a href="${e}">${e}</a></p>

                    <p>Please do not share your temporary password with anyone.</p>
                    
                </td>
            </tr>
        </table>

        <div class="footer">
            <p>&copy; ${t.currentYear} HelpDesk. All rights reserved.</p>
        </div>
    </center>
</body>
</html>
  `])},405257,e=>e.a(async(t,a)=>{try{var r=e.i(344732),s=e.i(661722),i=e.i(861464),n=e.i(510968),o=e.i(254799),l=t([i]);[i]=l.then?(await l)():l;let c=async({name:e,email:t})=>{try{let a=await (0,i.query)(`
      SELECT user_id, username, email, department
      FROM users WHERE email = $1 LIMIT 1
      `,[t]);if(a.length>0){let e=a[0];return{userId:e.user_id,name:e.username,email:e.email,department:e.department}}{let a=await (0,i.query)("SELECT name, email, department FROM company_user_records WHERE email = $1 LIMIT 1",[t]);if(0===a.length)return null;let l=a[0],c=o.default.randomUUID(),p=o.default.randomBytes(4).toString("hex"),d=await (0,n.hashPassword)(p),u=`
        INSERT INTO users
        (username, email, department, password, role, reset_token)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING user_id, username, email, department
        `,m=[l.name,l.email,l.department,d,"user",c],y=(await (0,i.query)(u,m))[0],h=(0,s.default)(`https://hotpoint-apps.ngrok.app/helpdesk/firstlogin?token=${c}`,p);return(0,r.sendEmail)({to:t,subject:`Welcome ${e}!`,html:h}),{userId:y.user_id,name:y.username,email:y.email,department:y.department}}}catch(e){return console.error("An error while trying to create/verify the behalf user:",e),null}};e.s(["CheckBehalfUser",0,c]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__0bfjsj9._.js.map