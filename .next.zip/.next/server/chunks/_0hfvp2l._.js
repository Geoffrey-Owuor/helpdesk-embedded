module.exports=[501441,e=>e.a(async(t,a)=>{try{var r=e.i(861464),s=e.i(89171),n=e.i(344732),i=e.i(758823),o=e.i(871917),l=t([r]);[r]=l.then?(await l)():l;let p=e=>new Promise(t=>setTimeout(t,e));async function d(e){if(e.nextUrl.searchParams.get("token")!==process.env.CRON_SECRET)return s.NextResponse.json({error:"Unauthorized"},{status:401});try{let e=(await (0,r.query)("SELECT department, emails FROM group_emails")).reduce((e,t)=>(e[t.department]=t.emails,e),{}),t=`
      SELECT 
        issue_uuid, issue_reference_id, issue_submitter_name, issue_submitter_department,
        issue_target_department, issue_priority, issue_type, issue_title, issue_description, 
        issue_status, issue_agent_name, issue_agent_email, issue_created_at, issue_updated_at
      FROM issues_table
      WHERE issue_status != $1
        AND issue_status != $2
        AND issue_created_at <= NOW() - INTERVAL '7 days'
    `,a=await (0,r.query)(t,["resolved","closed"]);if(0===a.length)return s.NextResponse.json({success:!0,message:"No unresolved issues found."},{status:200});let l={},d={};a.forEach(e=>{e.issue_agent_email&&(l[e.issue_agent_email]||(l[e.issue_agent_email]=[]),l[e.issue_agent_email].push(e));let t=e.issue_target_department;t&&(d[t]||(d[t]=[]),d[t].push(e))});let c=[];for(let[e,t]of Object.entries(l))c.push({to:e,subject:`[HelpDesk] ${t.length} Unresolved Issue${1!==t.length?"s":""} - Action Required`,nameOrDept:t[0].issue_agent_name||"Agent",issues:t,type:"Agent"});for(let[t,a]of Object.entries(d)){let r=e[t];r&&c.push({to:r,subject:`[HelpDesk] ${a.length} Unresolved Issue${1!==a.length?"s":""} - ${t} Summary`,nameOrDept:t,issues:a,type:"Department"})}let u=[];for(let e=0;e<c.length;e++){let t=c[e];try{let e=function(e,t){let a=t.map(e=>{let t,a;return t=Math.floor((Date.now()-new Date(e.issue_created_at).getTime())/864e5),a=`https://hotpoint-apps.ngrok.app/helpdesk/dashboard/${e.issue_uuid}?type=issue&title=${encodeURIComponent(e.issue_title)}&description=${encodeURIComponent(e.issue_description)}`,`
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
      background-color: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      margin-bottom: 20px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    ">
      <tr>
        <td style="padding: 24px;">
          
          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 16px;">
            <tr>
              <td align="left" valign="middle">
                <span style="font-family: 'Courier New', monospace; font-size: 13px; font-weight: 600; color: #6b7280; background: #f3f4f6; padding: 4px 8px; border-radius: 6px;">
                  ${e.issue_reference_id}
                </span>
              </td>
              <td align="right" valign="middle">
                <table cellpadding="0" cellspacing="0" border="0">
                  <tr>
                    <td style="padding-right: 8px;">
                      ${(0,i.renderPriorityBadge)(e.issue_priority)}
                    </td>
                    <td>
                      ${(0,i.renderStatusBadge)(e.issue_status)}
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>

          <h3 style="margin: 0 0 8px 0; font-size: 17px; font-weight: 700; color: #111827; line-height: 1.4;">
            ${e.issue_title}
          </h3>
          <p style="margin: 0 0 20px 0; font-size: 14px; color: #4b5563; line-height: 1.6;">
            ${e.issue_description||"<em style='color: #9ca3af;'>No description provided</em>"}
          </p>

          <table cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 24px;">
            <tr>
              <td align="left" style="border-radius: 6px; background-color: #111827;">
                <a href="${a}" target="_blank" style="display: inline-block; padding: 10px 20px; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 13px; font-weight: 600; color: #ffffff; text-decoration: none; border-radius: 6px; text-align: center;">
                  View Issue &rarr;
                </a>
              </td>
            </tr>
          </table>

          <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
            background-color: #f9fafb;
            border: 1px solid #f3f4f6;
            border-radius: 8px;
            padding: 16px;
          ">
            <tr>
              <td width="50%" valign="top" style="padding-right: 10px;">
                <div style="margin-bottom: 10px;">
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Submitter</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${e.issue_submitter_name}</span>
                </div>
                <div style="margin-bottom: 10px;">
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Assigned Agent</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${e.issue_agent_name||"Unassigned"}</span>
                </div>
                <div>
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Category</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${e.issue_type}</span>
                </div>
              </td>
              
              <td width="50%" valign="top">
                <div style="margin-bottom: 10px;">
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Created At</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${(0,o.dateFormatter)(e.issue_created_at)}</span>
                </div>
                <div style="margin-bottom: 10px;">
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Last Updated</span>
                  <span style="font-size: 13px; font-weight: 500; color: #1f2937;">${(0,o.dateFormatter)(e.issue_updated_at)}</span>
                </div>
                <div>
                  <span style="font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; display: block; margin-bottom: 2px;">Issue Age</span>
                  <span style="font-size: 13px; font-weight: 700; color: #dc2626;">${t} Days Unresolved</span>
                </div>
              </td>
            </tr>
          </table>

        </td>
      </tr>
    </table>`}).join(""),r=t.filter(e=>"Critical"===e.issue_priority).length,s=t.filter(e=>"High"===e.issue_priority).length;return`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Unresolved Issues Reminder</title>
</head>
<body style="
  margin: 0; padding: 0;
  background-color: transparent;
  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
">

  <table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr>
      <td align="center">
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width: 680px;">

          <tr>
            <td style="
              background: #171717;
              padding: 20px;
              border-radius: 20px 20px 0 0;
            ">
              <table width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td align="left">
                    <span style="
                      font-size: 20px;
                      font-weight: 600;
                      color: #ffffff;
                      letter-spacing: -0.3px;
                    ">Help<span style="color: #a3a3a3;">Desk</span></span>
                  </td>
                  <td align="right">
                    <span style="font-size: 11px; font-weight: 600; color: #737373; letter-spacing: 0.5px; text-transform: uppercase;">
                      Reminder
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>


          <tr>
            <td style="
              background: #ffffff;
              padding: 24px 0px;
            ">

              <table width="100%" cellpadding="0" cellspacing="0" border="0" style="
                background: #fef2f2;
                border: 1px solid #fecaca;
                border-left: 4px solid #dc2626;
                border-radius: 8px;
                margin-bottom: 32px;
              ">
                <tr>
                  <td style="padding: 16px 20px;">
                    <div style="font-size: 14px; font-weight: 700; color: #991b1b; margin-bottom: 6px;">
                      Issues Unresolved after 7 days
                    </div>
                    <p style="font-size: 13.5px; color: #b91c1c; margin: 0; line-height: 1.5;">
                      <strong>${e}</strong> has <strong>${t.length} unresolved issue${1!==t.length?"s":""}</strong>
                      that ${1!==t.length?"have":"has"} not been resolved after 7 days.
                      ${r>0?`<br><span style="margin-top: 6px; display: inline-block;">${r} Critical and ${s} High priority issue${r+s!==1?"s":""} need immediate action.</span>`:""}
                    </p>
                  </td>
                </tr>
              </table>

              <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 20px;">
                <tr>
                  <td style="
                    font-size: 12px; font-weight: 700;
                    text-transform: uppercase; letter-spacing: 1px;
                    color: #9ca3af; padding-bottom: 12px;
                    border-bottom: 2px solid #f3f4f6;
                  ">Open Issues - ${e}</td>
                </tr>
              </table>

              ${a}

              <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top: 40px; border-top: 1px solid #f3f4f6; padding-top: 24px;">
                <tr>
                  <td align="center">
                    <p style="font-size: 12px; color: #9ca3af; margin: 0 0 4px;">This is an automated reminder from</p>
                    <p style="font-size: 13px; font-weight: 700; color: #404040; margin: 0 0 12px; letter-spacing: -0.2px;">HelpDesk</p>
                    <p style="font-size: 11.5px; color: #d1d5db; margin: 0;">Please do not reply to this email directly.</p>
                  </td>
                </tr>
              </table>

            </td>
          </tr>

          <tr>
            <td style="padding-top: 24px;" align="center">
              <p style="font-size: 11px; color: #9ca3af; margin: 0;">
                \xa9 ${new Date().getFullYear()} HelpDesk. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>`}(t.nameOrDept,t.issues);await (0,n.sendEmail)({to:t.to,subject:t.subject,html:e}),u.push({recipient:t.to,type:t.type,sent:!0,count:t.issues.length})}catch(e){console.error(`[reminder-cron] Failed to send to ${t.to}:`,e),u.push({recipient:t.to,type:t.type,sent:!1,error:e instanceof Error?e.message:"Unknown error"})}e<c.length-1&&await p(3e3)}return s.NextResponse.json({success:!0,summary:u},{status:200})}catch(e){return console.error("[reminder-cron] Fatal error:",e),s.NextResponse.json({success:!1,error:e instanceof Error?e.message:String(e)},{status:500})}}e.s(["GET",0,d]),a()}catch(e){a(e)}},!1),129874,e=>e.a(async(t,a)=>{try{var r=e.i(747909),s=e.i(174017),n=e.i(996250),i=e.i(759756),o=e.i(561916),l=e.i(174677),d=e.i(869741),p=e.i(316795),c=e.i(487718),u=e.i(995169),g=e.i(47587),f=e.i(666012),h=e.i(570101),m=e.i(626937),x=e.i(10372),b=e.i(193695);e.i(820232);var y=e.i(600220),w=e.i(501441),v=t([w]);[w]=v.then?(await v)():v;let R=new r.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/triggers/issues-reminder/route",pathname:"/api/triggers/issues-reminder",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/triggers/issues-reminder/route.ts",nextConfigOutput:"",userland:w,...{}}),{workAsyncStorage:E,workUnitAsyncStorage:C,serverHooks:A}=R;async function _(e,t,a){a.requestMeta&&(0,i.setRequestMeta)(e,a.requestMeta),R.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/triggers/issues-reminder/route";r=r.replace(/\/index$/,"")||"/";let n=await R.prepare(e,t,{srcPage:r,multiZoneDraftMode:!1});if(!n)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:w,deploymentId:v,params:_,nextConfig:E,parsedUrl:C,isDraftMode:A,prerenderManifest:$,routerServerContext:k,isOnDemandRevalidate:N,revalidateOnlyGenerated:T,resolvedPathname:O,clientReferenceManifest:D,serverActionsManifest:H}=n,P=(0,d.normalizeAppPath)(r),S=!!($.dynamicRoutes[P]||$.routes[O]),U=async()=>((null==k?void 0:k.render404)?await k.render404(e,t,C,!1):t.end("This page could not be found"),null);if(S&&!A){let e=!!$.routes[O],t=$.dynamicRoutes[P];if(t&&!1===t.fallback&&!e){if(E.adapterPath)return await U();throw new b.NoFallbackError}}let z=null;!S||R.isDev||A||(z=O,z="/index"===z?"/":z);let I=!0===R.isDev||!S,q=S&&!I;H&&D&&(0,l.setManifestsSingleton)({page:r,clientReferenceManifest:D,serverActionsManifest:H});let j=e.method||"GET",M=(0,o.getTracer)(),F=M.getActiveScopeSpan(),L=!!(null==k?void 0:k.isWrappedByNextServer),B=!!(0,i.getRequestMeta)(e,"minimalMode"),K=(0,i.getRequestMeta)(e,"incrementalCache")||await R.getIncrementalCache(e,E,$,B);null==K||K.resetRequestCache(),globalThis.__incrementalCache=K;let V={params:_,previewProps:$.preview,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:I,incrementalCache:K,cacheLifeProfiles:E.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,s)=>R.onRequestError(e,t,r,s,k)},sharedContext:{buildId:w,deploymentId:v}},W=new p.NodeNextRequest(e),G=new p.NodeNextResponse(t),X=c.NextRequestAdapter.fromNodeNextRequest(W,(0,c.signalFromNodeResponse)(t));try{let n,i=async e=>R.handle(X,V).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=M.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=a.get("next.route");if(s){let t=`${j} ${s}`;e.setAttributes({"next.route":s,"http.route":s,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",s),n.updateName(t))}else e.updateName(`${j} ${r}`)}),l=async n=>{var o,l;let d=async({previousCacheEntry:s})=>{try{if(!B&&N&&T&&!s)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let r=await i(n);e.fetchMetrics=V.renderOpts.fetchMetrics;let o=V.renderOpts.pendingWaitUntil;o&&a.waitUntil&&(a.waitUntil(o),o=void 0);let l=V.renderOpts.collectedTags;if(!S)return await (0,f.sendResponse)(W,G,r,V.renderOpts.pendingWaitUntil),null;{let e=await r.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(r.headers);l&&(t[x.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==V.renderOpts.collectedRevalidate&&!(V.renderOpts.collectedRevalidate>=x.INFINITE_CACHE)&&V.renderOpts.collectedRevalidate,s=void 0===V.renderOpts.collectedExpire||V.renderOpts.collectedExpire>=x.INFINITE_CACHE?void 0:V.renderOpts.collectedExpire;return{value:{kind:y.CachedRouteKind.APP_ROUTE,status:r.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:s}}}}catch(t){throw(null==s?void 0:s.isStale)&&await R.onRequestError(e,t,{routerKind:"App Router",routePath:r,routeType:"route",revalidateReason:(0,g.getRevalidateReason)({isStaticGeneration:q,isOnDemandRevalidate:N})},!1,k),t}},p=await R.handleResponse({req:e,nextConfig:E,cacheKey:z,routeKind:s.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:$,isRoutePPREnabled:!1,isOnDemandRevalidate:N,revalidateOnlyGenerated:T,responseGenerator:d,waitUntil:a.waitUntil,isMinimalMode:B});if(!S)return null;if((null==p||null==(o=p.value)?void 0:o.kind)!==y.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});B||t.setHeader("x-nextjs-cache",N?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,h.fromNodeOutgoingHttpHeaders)(p.value.headers);return B&&S||c.delete(x.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,m.getCacheControlHeader)(p.cacheControl)),await (0,f.sendResponse)(W,G,new Response(p.value.body,{headers:c,status:p.value.status||200})),null};L&&F?await l(F):(n=M.getActiveScopeSpan(),await M.withPropagatedContext(e.headers,()=>M.trace(u.BaseServerSpan.handleRequest,{spanName:`${j} ${r}`,kind:o.SpanKind.SERVER,attributes:{"http.method":j,"http.target":e.url}},l),void 0,!L))}catch(t){if(t instanceof b.NoFallbackError||await R.onRequestError(e,t,{routerKind:"App Router",routePath:P,routeType:"route",revalidateReason:(0,g.getRevalidateReason)({isStaticGeneration:q,isOnDemandRevalidate:N})},!1,k),S)throw t;return await (0,f.sendResponse)(W,G,new Response(null,{status:500})),null}}e.s(["handler",0,_,"patchFetch",0,function(){return(0,n.patchFetch)({workAsyncStorage:E,workUnitAsyncStorage:C})},"routeModule",0,R,"serverHooks",0,A,"workAsyncStorage",0,E,"workUnitAsyncStorage",0,C]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=_0hfvp2l._.js.map