var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon1.png/route.js")
R.c("server/chunks/[externals]_next_dist_1ce_grm._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0xl422z.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/_next-internal_server_app_icon1_png_route_actions_00ocbxb.js")
R.m(486728)
module.exports=R.m(486728).exports
