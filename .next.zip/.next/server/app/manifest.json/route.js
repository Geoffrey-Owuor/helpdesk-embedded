var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.json/route.js")
R.c("server/chunks/[root-of-the-server]__0f1-e2h._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_manifest_json_route_actions_1ll_w5j.js")
R.m(288739)
module.exports=R.m(288739).exports
