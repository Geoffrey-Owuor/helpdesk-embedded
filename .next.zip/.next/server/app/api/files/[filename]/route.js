var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/files/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__18qmuij._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_files_[filename]_route_actions_1f2-luw.js")
R.m(70221)
module.exports=R.m(70221).exports
