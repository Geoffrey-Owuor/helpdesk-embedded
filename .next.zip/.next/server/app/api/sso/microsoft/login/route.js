var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sso/microsoft/login/route.js")
R.c("server/chunks/[root-of-the-server]__0mq42vj._.js")
R.c("server/chunks/node_modules_next_16bdwk4._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_arctic_dist_1or_ibd._.js")
R.c("server/chunks/_next-internal_server_app_api_sso_microsoft_login_route_actions_1xwro1n.js")
R.m(105309)
module.exports=R.m(105309).exports
