var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/triggers/issues-reminder/route.js")
R.c("server/chunks/[root-of-the-server]__1upghzv._.js")
R.c("server/chunks/[root-of-the-server]__1gdk9mq._.js")
R.c("server/chunks/node_modules_1f6jh4a._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_triggers_issues-reminder_route_actions_1pkd6xd.js")
R.m(129874)
module.exports=R.m(129874).exports
