var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/triggers/autoclose-issues/route.js")
R.c("server/chunks/[root-of-the-server]__18pz3d5._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_triggers_autoclose-issues_route_actions_0abiq1q.js")
R.m(664415)
module.exports=R.m(664415).exports
