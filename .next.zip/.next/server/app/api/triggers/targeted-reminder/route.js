var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/triggers/targeted-reminder/route.js")
R.c("server/chunks/[root-of-the-server]__0wj8lcu._.js")
R.c("server/chunks/[root-of-the-server]__1gdk9mq._.js")
R.c("server/chunks/node_modules_1f6jh4a._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_triggers_targeted-reminder_route_actions_1rp3lra.js")
R.m(19555)
module.exports=R.m(19555).exports
