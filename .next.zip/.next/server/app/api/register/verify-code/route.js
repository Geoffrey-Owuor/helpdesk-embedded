var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/register/verify-code/route.js")
R.c("server/chunks/[root-of-the-server]__0cxdaga._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_register_verify-code_route_actions_14hy664.js")
R.m(514330)
module.exports=R.m(514330).exports
