var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/healthcheck/route.js")
R.c("server/chunks/[root-of-the-server]__1g-s-6o._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_healthcheck_route_actions_217pnq4.js")
R.m(180635)
module.exports=R.m(180635).exports
