var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/forgot-password/route.js")
R.c("server/chunks/[root-of-the-server]__0vqtewq._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/node_modules_1f6jh4a._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/_next-internal_server_app_api_forgot-password_route_actions_0im3kz-.js")
R.m(442425)
module.exports=R.m(442425).exports
