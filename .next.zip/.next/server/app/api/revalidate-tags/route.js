var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/revalidate-tags/route.js")
R.c("server/chunks/[root-of-the-server]__1cdpp38._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_next_1ir7qn-._.js")
R.c("server/chunks/_next-internal_server_app_api_revalidate-tags_route_actions_0v1agp6.js")
R.m(111128)
module.exports=R.m(111128).exports
