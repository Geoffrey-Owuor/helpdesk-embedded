var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bug-report/route.js")
R.c("server/chunks/[root-of-the-server]__1biz5ll._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/node_modules_1f6jh4a._.js")
R.c("server/chunks/_next-internal_server_app_api_bug-report_route_actions_19a02-h.js")
R.m(632224)
module.exports=R.m(632224).exports
