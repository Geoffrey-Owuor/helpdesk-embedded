var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon0.svg/route.js")
R.c("server/chunks/[externals]_next_dist_1ce_grm._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_07r7myn.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/_next-internal_server_app_icon0_svg_route_actions_1r16s5a.js")
R.m(980619)
module.exports=R.m(980619).exports
