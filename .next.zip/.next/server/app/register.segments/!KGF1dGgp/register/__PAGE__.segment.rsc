1:"$Sreact.fragment"
2:I[980110,["/helpdesk/_next/static/chunks/42j46_j2g2zt1.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js","/helpdesk/_next/static/chunks/0k5g1496-2pv-.js","/helpdesk/_next/static/chunks/2z2ks65df7k6u.js"],"default"]
3:I[897367,["/helpdesk/_next/static/chunks/42j46_j2g2zt1.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/helpdesk/_next/static/chunks/0k5g1496-2pv-.js","async":true}],["$","script","script-1",{"src":"/helpdesk/_next/static/chunks/2z2ks65df7k6u.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"O8NYxfCrG40pYMwEZlTlf"}
5:null
