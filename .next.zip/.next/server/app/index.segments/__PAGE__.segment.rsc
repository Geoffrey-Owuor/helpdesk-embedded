1:"$Sreact.fragment"
2:I[816861,["/helpdesk/_next/static/chunks/42j46_j2g2zt1.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js","/helpdesk/_next/static/chunks/2z2ks65df7k6u.js","/helpdesk/_next/static/chunks/2ufhtis_6elp5.js","/helpdesk/_next/static/chunks/1nugw46uvfxf4.js","/helpdesk/_next/static/chunks/30em26osyb6cl.js"],"default"]
3:I[897367,["/helpdesk/_next/static/chunks/42j46_j2g2zt1.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/helpdesk/_next/static/chunks/2z2ks65df7k6u.js","async":true}],["$","script","script-1",{"src":"/helpdesk/_next/static/chunks/2ufhtis_6elp5.js","async":true}],["$","script","script-2",{"src":"/helpdesk/_next/static/chunks/1nugw46uvfxf4.js","async":true}],["$","script","script-3",{"src":"/helpdesk/_next/static/chunks/30em26osyb6cl.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"O8NYxfCrG40pYMwEZlTlf"}
5:null
