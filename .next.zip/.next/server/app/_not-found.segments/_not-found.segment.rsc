1:"$Sreact.fragment"
2:I[339756,["/helpdesk/_next/static/chunks/42j46_j2g2zt1.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
3:I[837457,["/helpdesk/_next/static/chunks/42j46_j2g2zt1.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"O8NYxfCrG40pYMwEZlTlf"}
