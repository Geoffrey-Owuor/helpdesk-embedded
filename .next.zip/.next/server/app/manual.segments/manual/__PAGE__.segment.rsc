1:"$Sreact.fragment"
2:I[853652,["/helpdesk/_next/static/chunks/1g-7_7iefah58.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js","/helpdesk/_next/static/chunks/1164gcj1o49kn.js","/helpdesk/_next/static/chunks/1k3m_jqqufy5_.js","/helpdesk/_next/static/chunks/1e27r2os882qd.js"],"default"]
3:I[897367,["/helpdesk/_next/static/chunks/1g-7_7iefah58.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/helpdesk/_next/static/chunks/1164gcj1o49kn.js","async":true}],["$","script","script-1",{"src":"/helpdesk/_next/static/chunks/1k3m_jqqufy5_.js","async":true}],["$","script","script-2",{"src":"/helpdesk/_next/static/chunks/1e27r2os882qd.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"ocYjUPSsWjP6AHAIDeUy7"}
5:null
