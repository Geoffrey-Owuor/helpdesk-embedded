1:"$Sreact.fragment"
2:I[897367,["/helpdesk/_next/static/chunks/2yl1jv4w6po1z.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js"],"ViewportBoundary"]
3:I[897367,["/helpdesk/_next/static/chunks/2yl1jv4w6po1z.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/helpdesk/_next/static/chunks/2yl1jv4w6po1z.js","/helpdesk/_next/static/chunks/1ntn7efqc-iiw.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"manifest","href":"/helpdesk/manifest.json"}],["$","link","1",{"rel":"icon","href":"/helpdesk/favicon.ico?favicon.266kpyvjc2w0s.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L5","2",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"O8NYxfCrG40pYMwEZlTlf"}
