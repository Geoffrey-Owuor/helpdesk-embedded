var R=require("../../chunks/[turbopack]_runtime.js")("server/app/apple-icon.png/route.js")
R.c("server/chunks/[externals]_next_dist_1ce_grm._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0qz67ql.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__21becu7._.js")
R.c("server/chunks/_next-internal_server_app_apple-icon_png_route_actions_0jcl8au.js")
R.m(794252)
module.exports=R.m(794252).exports
